﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HiTechShop.Models
{
    public class UserProfileViewModel
    {
        public TaiKhoan TaiKhoan { get; set; }
        public NguoiDung NguoiDung { get; set; }
    }
}